package Ejercicios

object Ejercicio126  {
  /**
   * Genera una lista de todas las sublistas de una lista dada.
   * data es la lista para la cual se generan las sublistas
   * Devuelve una lista que contiene todas las sublistas de data
   * */
  def allSublists[T](data: List[T]): List[List[T]] = {
    //Comienza con la lista vacia como la únic sublista de data
    var sublists: List[List[T]] = List(List())
    //Genera todas las sublistas de data desde la longitud 1 hasta la longitud de data
    for (length <- 1 to data.length) {
      //Genera las sublistas comenzando en cada indice
      for (i <- 0 to data.length - length) {
        //Añade la sublista actual a la lista de sublistas
        sublists = sublists :+ data.slice(i, i + length)
      }

    }
    //Devuelve el resultado
    sublists

  }
  /**
   *Demuestra la función allSublists.
   */
  def main(args:Array[String]):Unit={
    println("The sublists of [] are: "+allSublists(List()))
    println("The sublists of [1] are: "+allSublists(List(1)))
    println("The sublists of [1,2] are: "+allSublists(List(1,2)))
    println("The sublists of [1,2,3] are: "+allSublists(List(1,2,3)))
    println("The sublists of [1,2,3,4] are: "+allSublists(List(1,2,3,4)))
  }
}
