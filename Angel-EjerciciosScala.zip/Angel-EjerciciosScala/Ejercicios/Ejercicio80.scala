package Ejercicios
import  scala.util.Random
object Ejercicio80 {
  def flipCoin():Char={
    if(Random.nextBoolean()) 'H' else 'T'
  }
def simulateFlips():(String,Int)={
  var flips =List[Char]()
  while(flips.length<3 || !flips.takeRight(3).forall(_ =='H') && !flips.takeRight(3).forall(_=='T')){
    flips=flips:+ flipCoin()
  }
  (flips.mkString(""),flips.length)
}
  def main(args:Array[String]): Unit = {
    val numSimulations=10
    var totalFlips=0
    for(_ <- 1 to numSimulations){
      val(flipsStr,numFlips) =simulateFlips()
      totalFlips+=numFlips
      println(s"$flipsStr ($numFlips flips)")

    }
    val avergeFlips = totalFlips.toDouble/numSimulations
    println(f"En promedio, $avergeFlips%.1f lanzamientos fueron necesitados")
  }
}
