package Ejercicios

import scala.annotation.tailrec
import scala.io.Source
import java.io.File

object Ejercicio171{
  // Función recursiva para comprobar si una palabra se puede deletrear usando una lista de símbolos permitidos
  def canSpellWord(word: String, symbolsList: List[String]): (Boolean, String) = {
    val lowerWord = word.toLowerCase
    if (lowerWord.isEmpty) (true, "") // Si la palabra está vacía, se puede deletrear
    else {
      symbolsList.find(lowerWord.startsWith) match { // Buscar un símbolo en la lista que sea prefijo de la palabra
        case Some(symbol) =>
          val rest = canSpellWord(lowerWord.substring(symbol.length), symbolsList) // Llamar recursivamente con el resto de la palabra
          if (rest._1) (true, symbol.toUpperCase + rest._2) // Si el resto se puede deletrear, la palabra se puede deletrear también
          else (false, "") // Si no se puede deletrear el resto, la palabra completa no se puede deletrear
        case None => (false, "") // Si no se encuentra ningún símbolo que sea prefijo, la palabra no se puede deletrear
      }
    }
  }

  // Función para encontrar los elementos que se pueden deletrear usando solo los símbolos permitidos
  def findSpelledElements(elementsData: List[String], symbolsList: List[String]): List[(String, String)] = {
    elementsData.flatMap { line =>
      val Array(_, symbol, name) = line.split(",")
      val (result, symbolsUsed) = canSpellWord(name, symbolsList) // Comprobar si el nombre del elemento se puede deletrear
      if (result) Some(name -> symbolsUsed) // Si se puede deletrear, devolver el nombre del elemento y los símbolos utilizados
      else None // Si no se puede deletrear, no devolver nada
    }
  }

  def main(args: Array[String]): Unit = {
    // Leer los datos de elementos del archivo 'elements.txt'
    val elementsFile = "src/elements.txt" // Reemplazar con la ruta real del archivo
    val elementsData = Source.fromFile(elementsFile).getLines().toList

    // Crear la lista de símbolos permitidos a partir de los datos de elementos
    val symbolsList = elementsData.map(_.split(",")(1).toLowerCase)

    // Encontrar los elementos que se pueden deletrear usando solo los símbolos permitidos
    val spelledElements = findSpelledElements(elementsData, symbolsList)

    // Mostrar los elementos que se pueden deletrear y los símbolos utilizados para deletrearlos
    spelledElements.foreach { case (element, symbolsUsed) =>
      println(s"$element can be spelled as $symbolsUsed")
    }
  }

}

