package Ejercicios

object Ejercicio17  {
  def main(args: Array[String]): Unit = {
    //Definimos las constantes especificas
    val water_heat_capacity = 4.186
    val electricity_price = 8.9
    val j_to_kwh = 2.777e-7

    //Lee la cantidad de agua del usuario
    print("Ingresa la cantidad de agua en mililitros: ")
    val m = scala.io.StdIn.readFloat()

    print("Ingresa el aumento de temperatura (grados Celsisus): ")
    val d_temp = scala.io.StdIn.readFloat()

    //Calcula la energia en joules
    val q = m * d_temp * water_heat_capacity
    //Muestra el resultado en joules
    println(s"Se requieren $q Joules de energía.")

    //Calcula el costo de la electricidad
    val kwh = q * j_to_kwh
    val cost = kwh * electricity_price
    //Muestra el costo
    println(f"Esa cantidad de  energía costará $cost%.2f centavos.")
  }
}
