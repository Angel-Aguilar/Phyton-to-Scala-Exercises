package Ejercicios
import scala.io.StdIn._

object Ejercicio29  {
  def main(args:Array[String]):Unit={
    //Lee la temperatura en Celsius del usuario
    print("Ingresa la temmperatura en grados Celsius: ")
    val celsius =readDouble()
    //Convertimos la temperatura de Celsius a Farenheit
    val farenheit= (celsius*1.8)+32
    //Convertimos Celsius a Kelvin
    val kelvin=celsius+273.15
    //Mostramos los resultados
    println(f"Temperatura en Farenheit: $farenheit%.2f °F")
    println(f"Temperatura en Kelvin: $kelvin%.2f K")
  }


}
