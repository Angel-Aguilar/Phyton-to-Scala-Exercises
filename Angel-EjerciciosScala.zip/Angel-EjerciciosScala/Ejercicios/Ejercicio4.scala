package Ejercicios

object Ejercicio4 {
  def main(args: Array[String]): Unit = {
    val SQFT_PER_ACRE=43560
    //Lee la entrada del ususario
    print("Enter the lenght of the field in feet: ")
    val lenght = scala.io.StdIn.readFloat()

    print("Enter the width of the field in feet: ")
    val width = scala.io.StdIn.readFloat()
    //Calcula el area en acres
    val acres = lenght*width/SQFT_PER_ACRE
    //Muestra el resultado
    println(s"The area of the field is $acres acres")
  }
}