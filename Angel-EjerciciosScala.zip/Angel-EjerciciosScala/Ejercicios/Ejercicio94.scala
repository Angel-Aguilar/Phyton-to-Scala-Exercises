package Ejercicios
import scala.util.Random
object Ejercicio94 {
  val shortest = 7
  val longest = 10
  val min_ascii = 33
  val max_ascii = 126

  /**
   * Genera una contraseña aleatoria.
   * Devuelve una cadena que contiene una contraseña aleatoria
   */
  def randomPassword(): String = {
    //Selecciona una longitud aleatoria para la contraseña
    val randomLength = Random.nextInt(longest - shortest + 1) + shortest
    //Genera un número adecuado de caracteres aleatorios,agregando cada uno al final del resultado
    var resultado = ""
    for (_ <- 1 to randomLength) {
      val randomChar = (Random.nextInt(max_ascii - min_ascii + 1) + min_ascii).toChar
      resultado += randomChar
    }
    //Devuelve la contraseña aleatoria
    resultado
  }
  /**
   * * Genera y muestra una contraseña aleatoria.*/
  def main(args:Array[String]):Unit={
    println("Your random password is: "+randomPassword())
  }
}
