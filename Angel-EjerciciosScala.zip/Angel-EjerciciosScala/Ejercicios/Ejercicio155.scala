package Ejercicios
import scala.io.Source
import java.util.zip.ZipFile
import scala.collection.mutable


object Ejercicio155 {
  // Función para leer los archivos dentro del ZIP
  def readZipFile(zipFilePath: String, folderName: String, fileName: String): List[String] = {
    // Abre el archivo ZIP y obtiene la entrada correspondiente al nombre del archivo
    val zipFile = new ZipFile(zipFilePath)
    val entry = zipFile.getEntry(s"$folderName/$fileName")

    // Verifica si la entrada existe en el ZIP
    if (entry == null) {
      println(s"Archivo $fileName no encontrado en el ZIP.")
      return List() // Retorna una lista vacía si no se encontró el archivo
    }

    // Lee las líneas del archivo dentro del ZIP
    val stream = zipFile.getInputStream(entry)
    val lines = Source.fromInputStream(stream).getLines().toList
    stream.close()

    // Retorna las líneas del archivo como una lista de cadenas
    lines
  }

  // Función para procesar un archivo de nombres y devolver un conjunto de nombres
  def processFile(lines: List[String]): Set[String] = {
    // Divide cada línea por espacios en blanco y toma la primera palabra como el nombre
    lines.map(_.split("\\s+")(0).toLowerCase).toSet
  }

  def main(args: Array[String]): Unit = {
    println("Ingrese el año para analizar:")
    val year = scala.io.StdIn.readInt()

    // Verifica si el año está dentro del rango de datos disponibles
    if (year < 1900 || year > 2012) {
      println(s"No hay datos disponibles para el año $year.")
      return
    }

    // Ruta del archivo ZIP y nombres de los archivos dentro del ZIP
    val zipFilePath = "src/baby_names.zip"  // Asegúrate de que esta ruta sea correcta
    val folderName = "BabyNames"
    val boysFileName = s"${year}_BoysNames.txt"
    val girlsFileName = s"${year}_GirlsNames.txt"

    println(s"Procesando archivos: $boysFileName y $girlsFileName dentro del ZIP.")

    // Lee las líneas de los archivos de nombres para niños y niñas dentro del ZIP
    val boysLines = readZipFile(zipFilePath, folderName, boysFileName)
    val girlsLines = readZipFile(zipFilePath, folderName, girlsFileName)

    // Verifica si se encontraron datos en los archivos
    if (boysLines.isEmpty) {
      println(s"No se encontraron datos para niños en el año $year.")
      return
    }

    if (girlsLines.isEmpty) {
      println(s"No se encontraron datos para niñas en el año $year.")
      return
    }

    // Procesa los nombres para niños y niñas y encuentra los nombres neutrales
    val boysNames = processFile(boysLines)
    val girlsNames = processFile(girlsLines)

    val neutralNames = boysNames.intersect(girlsNames)

    // Imprime los nombres neutrales encontrados
    if (neutralNames.isEmpty) {
      println(s"No hay nombres neutrales para el año $year.")
    } else {
      println(s"Los nombres neutrales para el año $year son: ${neutralNames.mkString(", ")}")
    }
  }

}