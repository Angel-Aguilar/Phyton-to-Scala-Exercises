package Ejercicios
import scala.io.StdIn._
object Ejercicio170 {
  def construct(total: Double, monedas: Int): Boolean = {
    if (total == 0 && monedas == 0) {
      true
    } else if (total < 0 || monedas <= 0) {
      false
    } else {
      construct(total - 0.25, monedas - 1) || //Quarters
         construct(total - 0.1, monedas - 1) || //Dimes
        construct(total - 0.05, monedas - 1) || //Nickels
        construct(total-0.01, monedas-1)//Pennies
    }
  }
def main(args:Array[String]): Unit = {
  println("Ingresa la cantidad de dolares: ")
  val dolares=readDouble()

  println("Ingresa el número de monedas: ")
  val numMonedas= readInt()
  val resultado= construct(dolares,numMonedas)

  if(resultado){
    println("Es posible conrtruir el total usando el numero  especificado de monedas.")
  }else{
    println("No es posible construir el total")
  }
}
}
