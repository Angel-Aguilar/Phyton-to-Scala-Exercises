package Ejercicios
import scala.io.StdIn._
object Ejercicio35  {
  def main(args:Array[String]): Unit = {
    //Lee el número de años del perro del usuario
    print("Ingresa el número de años del perro: ")
    val dog_years= readDouble()
    //Checamos si hay una entrada negativa
    if(dog_years<0){
      println("Error: El número de años no puede ser negativo")
    }else{
      //Calcula los años del perro en años humnaos
      val human_years=if(dog_years<=2){
        dog_years*10.5
      }else{
        2*10.5+(dog_years-2)*4
      }
      //Mostramos el resultados
      println(f"El equivalente en años humanos de un perro es: $human_years%.2f")
    }

  }

}
