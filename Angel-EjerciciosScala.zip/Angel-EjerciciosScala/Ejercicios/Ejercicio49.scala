package Ejercicios
import scala.io.StdIn._
object Ejercicio49{
 def main(args:Array[String]): Unit = {
   //Lee la magnitud del usuario
   print("Ingresa la magnitud del terremoto: ")
   val magnitud =readDouble()
   //Determina la categoría basada en la magnitud
   val categoria= if(magnitud<2.0){
     "Micro"
   }else if(magnitud<3.0){
     "Very minor"
   }else if(magnitud<4.0){
     "Minor"
   }else if(magnitud<5.0){
     "Light"
   }else if(magnitud<6.0){
     "Moderate"
   }else if(magnitud<7.0){
     "Strong"
   }else if(magnitud<8.0){
     "Major"
   }else if(magnitud<10.0){
     "Great"
   }else{
     "Meteoric"
   }
   //Muestra el resultado
   println(f"La magnitud $magnitud%.1f del terremoto es considerado $categoria .")
 }
}
