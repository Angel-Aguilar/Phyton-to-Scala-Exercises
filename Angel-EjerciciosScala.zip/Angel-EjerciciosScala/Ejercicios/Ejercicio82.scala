package Ejercicios

import scala.io.StdIn._

object Ejercicio82  {
  val cuota_base: Double=4.00
  val cuota_140m: Double=0.25 //Cuota cada 140 metros
  val metrosPorKM: Double=1000.0
  val cuotaPorMetro: Double=cuota_140m/140
  //Función para calcular la cuota total con base a la distancia viajada en km
  def calcularCuota(distanciaKM: Double):Double={
    val distanciaMetros=distanciaKM*metrosPorKM
    cuota_base+(distanciaMetros*cuotaPorMetro)
  }
  def main(args:Array[String]): Unit = {
    //Demostrar la función
    print("Ingresa la distnacia recorrida en km: ")
    val distanciaKM=readDouble()
    //Calcular la cuota
    val cuota=calcularCuota(distanciaKM)
    //Muestra el resultado
    println(f"Distancia: $distanciaKM%.2f km, Cuota: $$ $cuota%.2f")
  }


}
