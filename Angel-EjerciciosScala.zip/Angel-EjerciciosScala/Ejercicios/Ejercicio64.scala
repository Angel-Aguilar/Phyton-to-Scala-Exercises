package Ejercicios
import scala.io.StdIn.readLine

object Ejercicio64 extends App {
  val pennies_per_nickel=5
  val nickel=0.05
  //Regsitro del total de todos los artículos.
  var total=0.0
  //Lee el precio de los artículos
  var line =readLine("Ingresa el precio del artículo (blank to quit): ")

  //Continua leyendo artículos hasta que se ingrese una línea en blanco
  while (line.nonEmpty){
    //Agregue el costo del artículo al total (después de convertirlo en float)
    total+=line.toFloat
    //Lee el costo del siguiente artículo
    line=readLine("Ingresa el precio del artículo (blank to quit): ")
  }
  //Muestra el total exacto a pagar
  println(f"El total exacto a pagar es ${total}%.2f")
  //Calcule la cantidad de centavos que quedarían si el total se pagara solo con monedas de cinco centavos.
  val roundingIndicator =(total*100 % pennies_per_nickel).toInt
  val cashTotal= if(roundingIndicator<pennies_per_nickel/2){
    //Si el número de centavos que quedan es menor que 2,5 entonces redondeamos hacia abajo restando ese número de centavos del total.
    total-roundingIndicator/100.0
  }else{
    //De lo contrario, sumamos una moneda de cinco centavos y luego restamos la cantidad de centavos.
    total+nickel-roundingIndicator/100.0
  }
  //Mostrar el monto en efectivo a pagar
  println(f"El monto en efectivo a pagar es ${cashTotal}%.2f5")


}
