package Ejercicios
import scala.io.StdIn._

object Ejercicio132 {
  def main(args:Array[String]): Unit = {
    val provinciasMap= Map( //Usamos map para identificar el primer caracater del codigo postal
      'A' -> "Newfoundland",
      'B'->"Nova Scotia",
      'C'-> "Prince Edward Island",
      'E'-> "New Brunswick",
      'G'->"Quebec",
      'H'-> "Quebec",
      'J'->"Quebec",
      'K'->"Ontario",
      'L'->"Ontario",
      'M'->"Ontario",
      'N'->"Ontario",
      'P'->"Ontario",
      'R'->"Manitoba",
      'S'->"Saskatchewan",
      'T'->"Alberta",
      'V'->"British Columbia",
      'X'->"Nunavut or Northwest Territories",
      'Y'->"Yukon"
    )
    print("Ingresa el codigo postal: ")
    val codigoPostal=readLine().trim.toUpperCase.replaceAll("\\s","") // \\s nos ayuda a omitir espacioa al principio del string

    if (codigoPostal.length !=6 || !codigoPostal.matches("[A-Z][0-9][A-Z][0-9][A-Z][0-9]")){//Utilizamos expresiones regulares para verificar si es válido el C.P.
      println("Formato invalido de codigo postal.")
      return
    }
    // Creamos valores para identificar el pirmer y segundo carácter
    val firstChar=codigoPostal.charAt(0)
    val secondChar=codigoPostal.charAt(1)
//Verificamos si el primer carácter es válido
    if(!provinciasMap.contains(firstChar)){
      println(s"El codigo postal inicia con una caracter invalido: $firstChar")
      return
    }
    //El resultado imprimira el tipo de vivienda y la provincia
    val provincia=provinciasMap(firstChar)
    val tipoVivienda= if(secondChar=='0') "rural" else "urbana"
    println(s"El codgio postal es una vivienda $tipoVivienda en $provincia.")
  }

}
