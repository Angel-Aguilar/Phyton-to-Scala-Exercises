package Ejercicios

import scala.io.StdIn._

object Ejercicio117  {
 def main(args:Array[String]):Unit={
   var continuarInput=true
   var xCoord=List[Double]()
   var yCoord=List[Double]()
   //Lee los puntos que se ingresan
   while (continuarInput){
     print("Ingresa el valor de x(línea vacia para finalizar): ")
     val xInput=readLine()
     if(xInput.isEmpty){
       //Termina el input cuando hay una línea vacía
       println("Input terminado.")
       println()
       //Salir del loop
       continuarInput=false
     }else{
       val x=xInput.toDouble

       println("Ingresa el valor de y: ")
       val y=readDouble()
       xCoord=xCoord:+x
       yCoord=yCoord:+y
     }
   }
   //Verificamos si hay los suficientes puntos (al menos 2)
   if(xCoord.length<2){
     println("Se requieren mínimo 2 puntos.")
     return
   }
   val n=xCoord.length
   //Calculamos las sumas para la fórmula
   val sumX=xCoord.sum
   val sumY=yCoord.sum
   val sumXY=xCoord.zip(yCoord).map({case(x,y)=> x*y}).sum
   val sumX2=xCoord.map(x=>x*x).sum

   //Calculamos la pendiente (m)
   val numeradorM=sumXY-(sumX*sumY)/n
   val denominadorM=sumX2-(sumX*sumX)/n
   val m=numeradorM/denominadorM

   //Calculamos la ordenada al origen (b)
   val avgX=sumX/n
   val avgY=sumY/n
   val b=avgY-m*avgX
   //Mostramos la recta de mejor ajuste
   println(f"La recta de mejor ajuste es: y=$m%.2f x + $b%.2f")
 }
}