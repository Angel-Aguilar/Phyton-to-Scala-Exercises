package Ejercicios
import scala.util.Random
object Ejercicio60 extends  App{
//Simlamos girar la ruleta,usando 37 para representar 00
  val value =Random.nextInt(38)
  if (value==37){
    println("El giro resultó en 00...")
  } else {
    println(s"El giro resulto en $value...")
  }

  //Muestra el pago para los números
  if(value==37){
    println("Paga a 00")
  } else{
    println(s"Paga a $value")
  }
  //Muestra los pagos para color(rojo o negro)

  if((value%2==1 && value>=1 && value<=9) ||
     (value%2==0 && value>=12 && value<=18) ||
     (value%2==1 && value>=19 && value<=27) ||
     (value%2==0 && value>=30 && value<=36)){
    println("Paga a Rojo")
  }else if(value==0 || value==37){
    //No hay pago para 0 o 00
  } else {
    println("Paga a Negro")
  }

  //Muestra el pago para pares e impares
  if(value>=1 && value<=36){
    if(value%2==1){
      println("Paga impares")
    }else{
      println("Paga pares")
    }
  }
  //Muestra los números bajos vs altos
  if(value>=1&& value<=18){
    println("Paga de 1 a 18")
  }else if(value>=19&& value<=36){
    println("Paga de 19 a 36")
  }
}
