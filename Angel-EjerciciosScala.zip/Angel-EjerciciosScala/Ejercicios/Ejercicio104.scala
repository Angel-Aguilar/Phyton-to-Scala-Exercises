package Ejercicios
import scala.collection.mutable.ListBuffer
import scala.io.StdIn.readLine

object Ejercicio104 extends  App {
  //Comienza con una lista vacía
  val data=ListBuffer[Int]()

  //Leer valores y agregarlos a la lista hasta que el usuario ingrese 0
  var num=readLine("Ingresa el entero (0 para salir): ").toInt

  while (num!=0){
    data.append(num)
    num=readLine("Ingresa el entero (0 para salir): ").toInt
  }
  //Ordenar los valores
  val sortedData=data.sorted
  //Mostrar los valores en orden  ascendente
  println("Los valores, ordenados en orden ascendente, son:")
  for (num <- sortedData){
    println(num)
  }
}
