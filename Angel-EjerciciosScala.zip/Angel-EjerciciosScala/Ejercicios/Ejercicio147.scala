package Ejercicios

import scala.io.Source

object Ejercicio147{
  // Función para limpiar una palabra eliminando signos de puntuación al inicio y final
  def limpiarPalabra(palabra: String): String = {
    palabra.replaceAll("^\\p{Punct}+|\\p{Punct}+$", "")
  }

  def main(args: Array[String]): Unit = {
    // Leer el nombre del archivo desde el usuario
    println("Ingrese el nombre del archivo:")
    val nombreArchivo = scala.io.StdIn.readLine()

    // Intentar leer el archivo y procesarlo
    try {
      // Leer todas las líneas del archivo
      val lineas = Source.fromFile(nombreArchivo).getLines().toList

      // Dividir cada línea en palabras, limpiarlas y convertirlas a minúsculas
      val palabras = lineas.flatMap(_.split("\\s+")).map(limpiarPalabra).map(_.toLowerCase)

      // Contar las ocurrencias de cada palabra usando view.mapValues seguido de toMap
      val conteoPalabras = palabras.groupBy(identity).view.mapValues(_.size).toMap

      // Encontrar la mayor cantidad de ocurrencias
      val maximoConteo = if (conteoPalabras.nonEmpty) conteoPalabras.values.max else 0

      // Filtrar las palabras que tienen la cantidad máxima de ocurrencias
      val palabrasMasFrecuentes = conteoPalabras.filter { case (_, conteo) => conteo == maximoConteo }.keys.toList

      // Mostrar las palabras más frecuentes en una lista
      if (palabrasMasFrecuentes.nonEmpty) {
        println(s"Las palabras más frecuentes con $maximoConteo ocurrencias son:")
        palabrasMasFrecuentes.foreach(palabra => println(s"- $palabra"))
      } else {
        println("No se encontraron palabras en el archivo.")
      }

    } catch {
      case e: Exception => println(s"Error al leer el archivo: ${e.getMessage}")
    }
  }
}
